package com.example.myapplication

import java.io.Serializable

data class Friend(var name: String, var birthdate: String) : Serializable