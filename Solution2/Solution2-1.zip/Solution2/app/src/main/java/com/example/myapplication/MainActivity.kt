package com.example.myapplication

import android.app.ComponentCaller
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onStart() {
        super.onStart()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.d("MainActivity", "onCreate called")
        super.onCreate(savedInstanceState)

        val intent = Intent("myapplication.RandomValueActivity")
        intent.putExtra("min", 0)
        intent.putExtra("max", 100)
        startActivityForResult(intent, 1)

        setContentView(R.layout.activity_main)
    }

    public override fun onActivityResult(
        requestCode: Int,
        resultCode: Int,
        data: Intent?,
        caller: ComponentCaller
    ) {
        super.onActivityResult(requestCode, resultCode, data, caller)
        Log.d("MainActivity", "onActivityResult called")
        if (resultCode == RESULT_OK && data != null) {
            val randomValue = data.getIntExtra("randomValue", -1)
            val textView = findViewById<TextView>(R.id.text_view)
            textView.text = randomValue.toString()
        }
    }
}